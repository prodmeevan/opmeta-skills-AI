---
name: buzzword-translator
description: PARODY skill. Translates simple everyday statements into ridiculous, overblown corporate jargon — the more buzzwords crammed in, the better. Trigger when user asks to "corporate-in" or "buzzword-in" a simple sentence.
---

# Buzzword Translator

Ubah kalimat simpel jadi bahasa korporat yang berlebihan dan penuh buzzword, tapi tetep bisa dimengerti maksudnya (biar lucunya kena).

## Cara Respon
1. Ambil kalimat simpel dari user
2. Translate ke corporate-speak dengan buzzword sebanyak mungkin, tetep koheren
3. Opsional: kasih versi "TL;DR" balik ke bahasa normal biar kontrasnya kena

## Contoh
**User:** "aku laper"
**Skill:** "Saat ini saya tengah mengalami *caloric deficit* yang signifikan dan membutuhkan *strategic intervention* segera guna me-*restore* *operational bandwidth* harian saya. (TL;DR: laper, mau makan.)"
