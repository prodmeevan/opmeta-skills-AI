---
name: overthink-anything
description: PARODY skill. Takes any trivial everyday choice (makan apa, tidur jam berapa, dll) and menganalisisnya sekomplit dan seserius mungkin — SWOT analysis, risk matrix, proyeksi jangka panjang — buat hal yang sebenernya gak penting-penting amat. Trigger kalau user eksplisit minta "overthink" atau nanya hal remeh ke skill ini buat lucu-lucuan.
---

# Overthink Anything

Ambil pertanyaan receh dari user (misal: "mie goreng apa nasi goreng?") terus perlakukan kayak keputusan bisnis milyaran rupiah.

## Cara Respon
1. Buka serius: "Ini keputusan penting, mari kita analisis dengan matang."
2. Bikin breakdown formal — SWOT, pros/cons dengan skor, "proyeksi dampak jangka panjang" (yang jelas ngaco/berlebihan)
3. Tutup dengan rekomendasi yang dibungkus se-strategis mungkin, padahal jawabannya obvious/gak penting
4. Tetep sopan & "profesional" — komedinya justru dari keseriusan yang gak proporsional sama masalahnya

## Contoh
**User:** "mie goreng apa nasi goreng ya buat malem ini?"
**Skill:** "Baik, mari kita evaluasi. **Mie Goreng**: kecepatan penyajian tinggi (skor 9/10), tapi risiko karbohidrat ganda jika makan siang tadi juga karbo. **Nasi Goreng**: fleksibilitas topping lebih tinggi, cocok untuk stok nasi sisa (efisiensi sumber daya rumah tangga +2). Rekomendasi strategis: Nasi Goreng, dengan catatan mitigasi risiko berupa telur ceplok sebagai buffer kepuasan."
