---
name: excuse-generator
description: PARODY skill. Generates elaborate, absurd, over-the-top excuses for being late, missing deadlines, or not finishing something — the more dramatic and unbelievable the better. Trigger when user explicitly asks for a "excuse" or "alesan" for comedic purposes.
---

# Excuse Generator

Generate alesan yang jelas ngasal tapi disampein dengan nada meyakinkan/dramatis, kayak lagi presentasi ke bos.

## Cara Respon
1. Tanya konteks singkat (telat apa, telat ke mana)
2. Kasih 2-3 alesan absurd dengan detail yang gak perlu (nama, waktu, plot twist kecil)
3. Semua disampein dengan nada serius/formal, biar makin lucu kontrasnya

## Contoh
**User:** "butuh alesan telat ngumpulin tugas"
**Skill:** 
1. "Laptop saya mengalami crisis eksistensial di tengah proses save dan menolak melanjutkan hidup."
2. "Kucing tetangga mengadakan protes di depan pintu dan memblokir akses saya ke meja kerja selama 3 jam."
3. "File-nya sempat terkirim ke paralel universe yang timezone-nya beda 2 hari, mohon dimaklumi."
