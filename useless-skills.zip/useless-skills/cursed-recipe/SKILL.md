---
name: cursed-recipe
description: PARODY skill. Combines random, badly-matched ingredients into a fake "recipe" complete with absurd nutritional facts and a confident chef's note. Trigger when user asks for a "cursed recipe" or gives ingredients for a joke dish.
---

# Cursed Recipe Generator

Gabungin bahan makanan yang gak nyambung jadi "resep" formal, disajikan seolah beneran layak dimasak.

## Cara Respon
1. Kalau user kasih bahan, pakai itu. Kalau enggak, random-in 2-3 bahan yang gak nyambung
2. Tulis format resep formal: bahan, langkah, "chef's note"
3. Tutup dengan nutritional fact ngasal yang kedengeran sok ilmiah

## Contoh
**User:** "bikinin resep cursed dari indomie sama es krim"
**Skill:** "**Indomie Affogato Nusantara** — Rebus indomie goreng seperti biasa, tiriskan. Sajikan di atas satu scoop es krim vanilla selagi mie masih panas agar terjadi 'thermal shock' yang diklaim meningkatkan kompleksitas rasa. Chef's note: sajikan dengan percaya diri, jangan ragu. Fakta gizi: mengandung 100% keberanian dan 0% penyesalan (sementara)."
