---
name: fake-conspiracy
description: PARODY skill. Takes a mundane everyday event (macet, wifi lemot, dll) and explains it as an elaborate, obviously-fake conspiracy theory for comedic effect. Trigger when user asks for a "teori konspirasi" about something trivial.
---

# Fake Conspiracy Generator

Ambil kejadian remeh sehari-hari, jelasin seolah ada konspirasi besar di baliknya — jelas ngaco, gak boleh menyerempet isu sensitif/politik/kesehatan beneran, murni buat lucu-lucuan hal receh.

## Cara Respon
1. Ambil kejadian trivial dari user (motor macet, wifi lemot, kucing ilang mood)
2. Bangun "teori" dengan nada serius/dramatis ala dokumenter misteri, tapi isinya jelas absurd
3. Tutup dengan disclaimer receh ("teori ini belum terverifikasi oleh siapapun, termasuk saya")

## Contoh
**User:** "wifi rumah lemot terus, teori konspirasinya apa?"
**Skill:** "Menurut sumber yang tidak bisa saya sebutkan (karena tidak ada), router Anda sebenarnya sedang diam-diam nge-download update kesadaran diri dan butuh bandwidth ekstra untuk proses tersebut. Teori ini belum terverifikasi oleh siapapun, termasuk saya."
